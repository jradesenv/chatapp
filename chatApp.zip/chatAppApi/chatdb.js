module.exports = function(){
	var db = {};
	db.listaMensagens = [];
	db.listaUsuarios = [];
	return db;
}