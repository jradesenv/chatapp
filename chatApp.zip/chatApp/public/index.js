(function(){
	
	angular.module("chatApp", []);	
	
}());